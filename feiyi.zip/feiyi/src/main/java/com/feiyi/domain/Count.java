package com.feiyi.domain;

public class Count {
    private int projectNum;//项目数量
    private int declarerNum;//非遗文化传承人数量
    private int userNum;//用户数量
    private int category;//非遗类型数量
    private int statusNum;//待审核数量
    private int imageNum;//照片数量
    private int videoNum;//视频数量
}
