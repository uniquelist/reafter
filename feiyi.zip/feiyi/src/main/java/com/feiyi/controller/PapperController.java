package com.feiyi.controller;

import com.feiyi.domain.Papper;
import com.feiyi.service.PapperService;

import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Validated
@CrossOrigin
@RestController
@RequestMapping("papper")
public class PapperController {

    @Autowired
    PapperService papperService;

    //查询非遗传承人列表
    @GetMapping("/findAll")
    public PageInfo<Papper> findAll(@RequestParam(defaultValue = "1") int currentPage, @RequestParam(defaultValue = "6") int size) {
        System.out.println(currentPage+"...."+size);
        PageInfo<Papper> pageInfo = papperService.findAll(currentPage, size);
        return pageInfo;
    }

    @GetMapping("/findAllFont")
    public List<Papper> findAll() {
        return papperService.findAll();
    }
    /*public List<Papper> findAll(){
        return papperService.findAll();
    }*/

    //添加非遗传承人
    @PostMapping("/addPapper")
    public String addDeclarer(@RequestBody Papper papper){
        // 保存演员的信息
        papperService.addPapper(papper);
        return "提交成功!!";
    }

    // 删除一条记录
    @PostMapping("/delete")
    public String deleteById(@RequestBody Papper papper){
       papperService.deleteById(papper.getId());
        return "删除成功";
    }

    @RequestMapping(value = "/searchPapper/{pageCode}/{pageSize}",method = RequestMethod.GET)
    public PageInfo<Papper> searchPapper(@PathVariable(value = "pageCode") int pageCode, @PathVariable(value = "pageSize") int pageSize,String keyword) {
        System.out.println(pageCode+"...."+pageSize);
        PageInfo<Papper> pageInfo = papperService.searchPapper(pageCode, pageSize,keyword);
        return pageInfo;
    }
}
